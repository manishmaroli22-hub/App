package com.example.dailywallpaper

import android.content.Context

object Prefs {
    const val SOURCE_GALLERY = 0
    const val SOURCE_ONLINE = 1
    const val TARGET_BOTH = 0
    const val TARGET_HOME = 1
    const val TARGET_LOCK = 2

    private fun sp(c: Context) = c.getSharedPreferences("daily_wallpaper", Context.MODE_PRIVATE)

    fun getUris(c: Context): List<String> =
        (sp(c).getString("uris", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun setUris(c: Context, uris: List<String>) =
        sp(c).edit().putString("uris", uris.joinToString("\n")).apply()

    fun getIndex(c: Context) = sp(c).getInt("index", 0)
    fun setIndex(c: Context, v: Int) = sp(c).edit().putInt("index", v).apply()

    fun getSource(c: Context) = sp(c).getInt("source", SOURCE_ONLINE)
    fun setSource(c: Context, v: Int) = sp(c).edit().putInt("source", v).apply()

    fun getTarget(c: Context) = sp(c).getInt("target", TARGET_BOTH)
    fun setTarget(c: Context, v: Int) = sp(c).edit().putInt("target", v).apply()

    fun getHour(c: Context) = sp(c).getInt("hour", 8)
    fun getMinute(c: Context) = sp(c).getInt("minute", 0)
    fun setTime(c: Context, h: Int, m: Int) =
        sp(c).edit().putInt("hour", h).putInt("minute", m).apply()

    fun isEnabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()
}
