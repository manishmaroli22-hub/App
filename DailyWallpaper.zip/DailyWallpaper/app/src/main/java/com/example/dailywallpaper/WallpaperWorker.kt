package com.example.dailywallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class WallpaperWorker(private val ctx: Context, params: WorkerParameters) :
    CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val dm = ctx.resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels

            val bitmap: Bitmap? = if (Prefs.getSource(ctx) == Prefs.SOURCE_ONLINE) {
                loadOnline(w, h)
            } else {
                loadFromGallery(w, h)
            }

            if (bitmap == null) return@withContext Result.retry()

            val flags = when (Prefs.getTarget(ctx)) {
                Prefs.TARGET_HOME -> WallpaperManager.FLAG_SYSTEM
                Prefs.TARGET_LOCK -> WallpaperManager.FLAG_LOCK
                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            }
            WallpaperManager.getInstance(ctx).setBitmap(bitmap, null, true, flags)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun loadOnline(w: Int, h: Int): Bitmap? {
        val url = URL("https://picsum.photos/$w/$h?random=${System.currentTimeMillis()}")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        return conn.inputStream.use { BitmapFactory.decodeStream(it) }
    }

    private fun loadFromGallery(w: Int, h: Int): Bitmap? {
        val uris = Prefs.getUris(ctx)
        if (uris.isEmpty()) return null
        val idx = Prefs.getIndex(ctx) % uris.size
        val uri = Uri.parse(uris[idx])

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

        var sample = 1
        while (bounds.outWidth / (sample * 2) >= w && bounds.outHeight / (sample * 2) >= h) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        }
        Prefs.setIndex(ctx, (idx + 1) % uris.size)
        return bmp
    }
}
