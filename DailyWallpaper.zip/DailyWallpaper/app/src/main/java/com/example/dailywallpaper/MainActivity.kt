package com.example.dailywallpaper

import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.util.Calendar
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var countText: TextView
    private lateinit var timeButton: MaterialButton
    private lateinit var enableSwitch: MaterialSwitch

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            uris.forEach {
                try {
                    contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
            }
            Prefs.setUris(this, uris.map { it.toString() })
            Prefs.setIndex(this, 0)
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(text: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
            this.text = text
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, pad / 2, 0, pad / 4)
        }

        root.addView(label("Daily Wallpaper", 26f, true))
        root.addView(label("Automatically changes your wallpaper once a day."))

        // Source
        root.addView(label("Wallpaper source", 16f, true))
        val sourceGroup = RadioGroup(this)
        val rbOnline = RadioButton(this).apply { text = "Random online photos"; id = 1001 }
        val rbGallery = RadioButton(this).apply { text = "My own photos"; id = 1002 }
        sourceGroup.addView(rbOnline); sourceGroup.addView(rbGallery)
        sourceGroup.check(if (Prefs.getSource(this) == Prefs.SOURCE_ONLINE) 1001 else 1002)
        sourceGroup.setOnCheckedChangeListener { _, id ->
            Prefs.setSource(this, if (id == 1001) Prefs.SOURCE_ONLINE else Prefs.SOURCE_GALLERY)
            if (Prefs.isEnabled(this)) schedule()
        }
        root.addView(sourceGroup)

        countText = label("")
        root.addView(countText)
        root.addView(MaterialButton(this).apply {
            text = "Choose photos"
            setOnClickListener { picker.launch(arrayOf("image/*")) }
        })

        // Target
        root.addView(label("Apply to", 16f, true))
        val targetGroup = RadioGroup(this)
        listOf("Home + Lock screen" to 2001, "Home screen only" to 2002, "Lock screen only" to 2003).forEach { (t, id) ->
            targetGroup.addView(RadioButton(this).apply { text = t; this.id = id })
        }
        targetGroup.check(2001 + Prefs.getTarget(this))
        targetGroup.setOnCheckedChangeListener { _, id -> Prefs.setTarget(this, id - 2001) }
        root.addView(targetGroup)

        // Time
        root.addView(label("Change time", 16f, true))
        timeButton = MaterialButton(this).apply {
            setOnClickListener {
                TimePickerDialog(this@MainActivity, { _, h, m ->
                    Prefs.setTime(this@MainActivity, h, m)
                    refresh()
                    if (Prefs.isEnabled(this@MainActivity)) schedule()
                }, Prefs.getHour(this@MainActivity), Prefs.getMinute(this@MainActivity), false).show()
            }
        }
        root.addView(timeButton)

        // Enable
        enableSwitch = MaterialSwitch(this).apply {
            text = "Change wallpaper every day"
            isChecked = Prefs.isEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                Prefs.setEnabled(this@MainActivity, on)
                if (on) {
                    if (Prefs.getSource(this@MainActivity) == Prefs.SOURCE_GALLERY &&
                        Prefs.getUris(this@MainActivity).isEmpty()) {
                        Toast.makeText(this@MainActivity, "Choose some photos first", Toast.LENGTH_SHORT).show()
                        isChecked = false
                        return@setOnCheckedChangeListener
                    }
                    schedule()
                    Toast.makeText(this@MainActivity, "Daily change enabled", Toast.LENGTH_SHORT).show()
                } else {
                    WorkManager.getInstance(this@MainActivity).cancelUniqueWork("daily_wallpaper")
                }
            }
        }
        root.addView(enableSwitch, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = pad })

        root.addView(MaterialButton(this).apply {
            text = "Change wallpaper now"
            setOnClickListener {
                if (Prefs.getSource(context) == Prefs.SOURCE_GALLERY && Prefs.getUris(context).isEmpty()) {
                    Toast.makeText(context, "Choose some photos first", Toast.LENGTH_SHORT).show()
                } else {
                    WorkManager.getInstance(context).enqueue(OneTimeWorkRequestBuilder<WallpaperWorker>().build())
                    Toast.makeText(context, "Changing wallpaper…", Toast.LENGTH_SHORT).show()
                }
            }
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = pad })

        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun refresh() {
        countText.text = "${Prefs.getUris(this).size} photo(s) selected"
        val h = Prefs.getHour(this)
        val m = Prefs.getMinute(this)
        val amPm = if (h < 12) "AM" else "PM"
        val h12 = if (h % 12 == 0) 12 else h % 12
        timeButton.text = String.format("%d:%02d %s", h12, m, amPm)
    }

    private fun schedule() {
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, Prefs.getHour(this@MainActivity))
            set(Calendar.MINUTE, Prefs.getMinute(this@MainActivity))
            set(Calendar.SECOND, 0)
            if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        val delay = next.timeInMillis - now.timeInMillis

        val builder = Constraints.Builder()
        if (Prefs.getSource(this) == Prefs.SOURCE_ONLINE) builder.setRequiredNetworkType(NetworkType.CONNECTED)

        val request = PeriodicWorkRequestBuilder<WallpaperWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setConstraints(builder.build())
            .build()

        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("daily_wallpaper", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}
