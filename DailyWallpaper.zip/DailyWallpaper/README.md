# Daily Wallpaper (Android)

Changes your phone wallpaper automatically once a day.

Features: random online photos or your own photos (rotated in order), home / lock / both,
choose the daily time, "Change now" button. Min Android 7.0 (API 24).

## Build the APK
**Option A – Android Studio:** File > Open this folder, wait for Gradle sync,
then Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk

**Option B – GitHub (no PC tools needed):** push this folder to a GitHub repo, open the
Actions tab > "Build APK" > Run workflow, then download the artifact.

Install the APK on your phone (allow "install unknown apps").
Note: some phones (Xiaomi, Oppo, Samsung, etc.) need battery optimization turned off for this app
so the daily change isn't delayed.
